const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const router = express.Router();

module.exports = (db) => {
  router.post('/register', async (req, res) => {
    const { name, email, password, role } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      await db.query('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)', [name, email, hashedPassword, role]);
      res.json({ success: true, message: 'تم إنشاء الحساب' });
    } catch (err) {
      res.status(400).json({ error: 'البريد مستخدم' });
    }
  });
  
  router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) return res.status(401).json({ error: 'بيانات غير صحيحة' });
    
    const user = rows[0];
    if (!await bcrypt.compare(password, user.password)) return res.status(401).json({ error: 'بيانات غير صحيحة' });
    
    const token = jwt.sign({ id: user.id, role: user.role }, 'SECRET_KEY', { expiresIn: '1d' });
    res.json({ success: true, token, user: { id: user.id, name: user.name, role: user.role, balance: user.wallet_balance } });
  });
  return router;
};