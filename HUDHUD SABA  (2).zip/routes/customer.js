const express = require('express');
const router = express.Router();

module.exports = (db, auth) => {
  // جلب المنتجات
  router.get('/products', auth, async (req, res) => {
    const [rows] = await db.query('SELECT p.*, u.name as merchant_name FROM products p JOIN users u ON p.merchant_id = u.id');
    res.json(rows);
  });
  
  // شراء منتج
  router.post('/buy', auth, async (req, res) => {
    const { product_id } = req.body;
    const [product] = await db.query('SELECT * FROM products WHERE id = ?', [product_id]);
    const total = product[0].price + 5; // 5 رسوم توصيل
    
    const [user] = await db.query('SELECT wallet_balance FROM users WHERE id = ?', [req.user.id]);
    if (user[0].wallet_balance < total) return res.status(400).json({ error: 'رصيد غير كافٍ' });
    
    await db.query('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?', [total, req.user.id]);
    await db.query('INSERT INTO orders (order_code, customer_id, merchant_id, total_amount) VALUES (?, ?, ?, ?)', ['ORD-' + Date.now(), req.user.id, product[0].merchant_id, total]);
    
    res.json({ success: true, message: 'تم الشراء وحجز المبلغ' });
  });
  return router;
};