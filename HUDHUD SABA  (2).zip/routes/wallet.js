const express = require('express');
const router = express.Router();

module.exports = (db, auth) => {
  router.post('/deposit', auth, async (req, res) => {
    await db.query('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?', [req.body.amount, req.user.id]);
    res.json({ success: true, message: 'تم شحن الرصيد' });
  });
  
  router.get('/balance', auth, async (req, res) => {
    const [rows] = await db.query('SELECT wallet_balance FROM users WHERE id = ?', [req.user.id]);
    res.json({ balance: rows[0].wallet_balance });
  });
  return router;
};