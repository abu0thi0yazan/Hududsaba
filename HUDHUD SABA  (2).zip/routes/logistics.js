const express = require('express');
const router = express.Router();

module.exports = (db, auth) => {
  // جلب الطلبات التي لم يتم قبولها
  router.get('/orders', auth, async (req, res) => {
    const [rows] = await db.query('SELECT * FROM orders WHERE logistics_id IS NULL');
    res.json(rows);
  });
  
  // قبول الطلب
  router.post('/accept', auth, async (req, res) => {
    await db.query('UPDATE orders SET logistics_id = ?, status = "shipped" WHERE id = ?', [req.user.id, req.body.order_id]);
    res.json({ success: true, message: 'تم قبول الطلب' });
  });
  return router;
};