const express = require('express');
const router = express.Router();

module.exports = (db, auth) => {
  router.post('/products', auth, async (req, res) => {
    const { name, description, price } = req.body;
    await db.query('INSERT INTO products (merchant_id, name, description, price) VALUES (?, ?, ?, ?)', [req.user.id, name, description, price]);
    res.json({ success: true, message: 'تم إضافة المنتج' });
  });
  return router;
};