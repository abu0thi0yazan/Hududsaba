const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// إعدادات قاعدة البيانات (تأكد من وضع بيانات استضافتك هنا)
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'hudhud_db'
});

// دالة مساعدة للتحقق من التوكن (Middleware)
const authenticateToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'غير مصرح' });
  
  const jwt = require('jsonwebtoken');
  jwt.verify(token, 'SECRET_KEY', (err, user) => {
    if (err) return res.status(403).json({ error: 'انتهت الجلسة' });
    req.user = user;
    next();
  });
};

// ربط المسارات وتمرير قاعدة البيانات ودالة التحقق
app.use('/api/auth', require('./routes/auth')(db));
app.use('/api/wallet', require('./routes/wallet')(db, authenticateToken));
app.use('/api/merchant', require('./routes/merchant')(db, authenticateToken));
app.use('/api/customer', require('./routes/customer')(db, authenticateToken));
app.use('/api/logistics', require('./routes/logistics')(db, authenticateToken));
