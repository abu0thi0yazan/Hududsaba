const express = require('express');
const router = express.Router();
const db = require('../data/db');

// تسجيل الدخول (معدل لحل المشكلة)
router.post('/login', (req, res) => {
    // استقبلنا المتغير role من الواجهة، لكننا لن نستخدمه في شرط البحث
    const { email, password, role } = req.body;
    
    // 1. نبحث عن المستخدم بالإيميل والباسورد فقط
    const user = db.users.find(u => u.email === email && u.password === password);
    
    if (user) {
        // 2. إذا كان محظوراً، نمنعه
        if (user.status === 'banned') {
            return res.status(403).json({ success: false, message: 'هذا الحساب محظور. يرجى التواصل مع الدعم.' });
        }
        
        // 3. إذا كان البريد والباسورد صحيحين، نرسل بياناته (بما فيها دوره الحقيقي)
        res.json({
            success: true,
            user: {
                id: user.id,
                accountNumber: user.accountNumber,
                name: user.name,
                role: user.role // نرسل الدور الحقيقي من قاعدة البيانات
            }
        });
    } else {
        res.status(401).json({ success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
    }
});

// تعديل كلمة المرور
router.post('/change-password', (req, res) => {
    const { email, oldPassword, newPassword } = req.body;
    const userIndex = db.users.findIndex(u => u.email === email && u.password === oldPassword);
    if (userIndex !== -1) {
        db.users[userIndex].password = newPassword;
        res.json({ success: true, message: 'تم تغيير كلمة المرور بنجاح' });
    } else {
        res.status(400).json({ success: false, message: 'كلمة المرور القديمة خاطئة' });
    }
});

module.exports = router;