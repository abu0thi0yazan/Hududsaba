const express = require('express');
const router = express.Router();
const db = require('../data/db');

// إحصائيات
router.get('/stats', (req, res) => {
  res.json({
    users: db.users.length,
    products: db.products.length,
    complaints: db.complaints.length
  });
});

// جلب كل المستخدمين
router.get('/users', (req, res) => res.json(db.users));

// البحث عن مستخدم برقم الحساب
router.get('/users/:accountNumber', (req, res) => {
  const user = db.users.find(u => u.accountNumber === req.params.accountNumber);
  if (user) res.json(user);
  else res.status(404).json({ message: 'المستخدم غير موجود' });
});

// حظر مستخدم
router.post('/ban/:id', (req, res) => {
  const user = db.users.find(u => u.id == req.params.id);
  if (user) {
    user.status = 'banned';
    res.json({ success: true, message: 'تم حظر الحساب' });
  } else res.status(404).json({ success: false });
});

// جلب البلاغات
router.get('/complaints', (req, res) => res.json(db.complaints));

// تقديم بلاغ (من قبل مستخدم)
router.post('/complaints', (req, res) => {
  const { reporterAccount, reportedAccount, reason } = req.body;
  const complaint = { id: Date.now(), reporterAccount, reportedAccount, reason, status: 'pending' };
  db.complaints.push(complaint);
  res.json({ success: true, message: 'تم إرسال البلاغ للإدارة' });
});

module.exports = router;