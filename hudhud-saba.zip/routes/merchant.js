const express = require('express');
const router = express.Router();
const db = require('../data/db');

// جلب منتجات التاجر
router.get('/products/:merchantId', (req, res) => {
  const products = db.products.filter(p => p.merchantId == req.params.merchantId);
  res.json(products);
});

// إضافة منتج
router.post('/products', (req, res) => {
  const { merchantId, name, price, category } = req.body;
  const newProduct = { id: Date.now(), merchantId, name, price, category };
  db.products.push(newProduct);
  res.json({ success: true, product: newProduct });
});

// حذف منتج
router.delete('/products/:id', (req, res) => {
  db.products = db.products.filter(p => p.id != req.params.id);
  res.json({ success: true, message: 'تم حذف المنتج' });
});

module.exports = router;