const express = require('express');
const router = express.Router();
const db = require('../data/db');

// تسجيل الدخول
router.post('/login', (req, res) => {
    const { email, password, role } = req.body;
    const user = db.users.find(u => u.email === email && u.password === password && u.role === role);
    if (user) {
        if (user.status === 'banned') return res.status(403).json({ success: false, message: 'هذا الحساب محظور.' });
        res.json({ success: true, user: { id: user.id, accountNumber: user.accountNumber, name: user.name, role: user.role } });
    } else {
        res.status(401).json({ success: false, message: 'بيانات الدخول غير صحيحة' });
    }
});

// إنشاء حساب جديد
router.post('/register', (req, res) => {
    const { name, email, password, role } = req.body;
    if (db.users.find(u => u.email === email)) {
        return res.status(400).json({ success: false, message: 'البريد الإلكتروني مستخدم بالفعل' });
    }
    const newUser = {
        id: db.nextId++,
        accountNumber: `HS-${db.nextAccount++}`,
        email, password, role, name, status: 'active'
    };
    db.users.push(newUser);
    res.json({ success: true, message: `تم إنشاء الحساب بنجاح. رقم حسابك هو: ${newUser.accountNumber}`, accountNumber: newUser.accountNumber });
});

// تعديل كلمة المرور
router.post('/change-password', (req, res) => {
    const { email, oldPassword, newPassword } = req.body;
    const userIndex = db.users.findIndex(u => u.email === email && u.password === oldPassword);
    if (userIndex !== -1) {
        db.users[userIndex].password = newPassword;
        res.json({ success: true, message: 'تم تغيير كلمة المرور بنجاح' });
    } else {
        res.status(400).json({ success: false, message: 'كلمة المرور القديمة خاطئة' });
    }
});

module.exports = router;