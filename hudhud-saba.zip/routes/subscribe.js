const express = require('express');
const router = express.Router();
const db = require('../data/db');

router.post('/subscribe', (req, res) => {
  const { email } = req.body;
  if (!db.subscribers.includes(email)) {
    db.subscribers.push(email);
    res.json({ success: true, message: 'تم الاشتراك في النشرة البريدية' });
  } else {
    res.json({ success: true, message: 'أنت مشترك بالفعل' });
  }
});

module.exports = router;